﻿public class Knife : Ammunition
{
    private const double weight = 0.4;

    public override double Weight => weight;
}
