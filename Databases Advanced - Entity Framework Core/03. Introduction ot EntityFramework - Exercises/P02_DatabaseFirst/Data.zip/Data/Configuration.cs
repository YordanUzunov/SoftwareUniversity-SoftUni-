﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=DANIMAL\\SQLEXPRESS;Database=SoftUni;Trusted_Connection=True;";
    }
}
